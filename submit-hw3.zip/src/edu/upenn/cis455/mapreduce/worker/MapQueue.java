package edu.upenn.cis455.mapreduce.worker;

import java.util.LinkedList;

/**
 * Holds the key value pairs from the input files
 *
 */
public class MapQueue {
	
	public static LinkedList <String> mapQueue = new LinkedList<String>();
}
